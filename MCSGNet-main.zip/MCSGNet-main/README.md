# MCSGNet

## Project Profile

This repository presents the experimental results of MCSGNet. We provide images from the Miao embroidery dataset together with the corresponding degradation masks.



#### **Mask-Conditioned Spectral Gating for Heritage Embroidery Inpainting with Improved High-Frequency and Directional Consistency**

Miao embroidery is a living form of intangible cultural heritage whose visual identity depends on motif, thread density, color and stitch direction. Digital inpainting can support documentation and exhibition, but existing methods often treat the damage mask only as a spatial region to be filled. This formulation is insufficient because compact losses, long tears and fragmented stains remove different spatial frequencies, while global spectral priors can smooth stitch-scale detail or impose a class-average texture. We propose MCSGNet, a mask-conditioned spectral gating network for Miao embroidery inpainting. A 22-dimensional descriptor of damage geometry and visible-context spectra modulates low-rank FFT-band gains. A dual-domain block combines depthwise spatial filtering, Haar-wavelet analysis and Gabor responses to model stitch edges and directional thread structure. Context-calibrated spectral supervision, a directional-consistency constraint and a mask-conditioned multiscale discriminator align restored high-frequency content with the surrounding fabric. We constructed a 64,683-image dataset across six Miao embroidery traditions and divided it into 819 indivisible source groups with leakage-free training, validation and test partitions. MCSGNet achieved higher PSNR and SSIM and lower LPIPS than representative methods across 0.1–30% mask coverage. Expert assessment also favored MCSGNet overall, and a cross-style test on a Qing-dynasty embroidery produced structurally coherent completions. On a 115-image semi-synthetic high-resolution test subset, MCSGNet reduced high-frequency ratio error and angular-energy divergence relative to all six baselines, while remaining competitive in global radial-spectrum and orientation error. MCSGNet therefore provides a reproducible digital-reference workflow for heritage documentation and museum interpretation, while remaining distinct from physical conservation. 

**Code**

We will release the training code, testing scripts, and related components at an appropriate time.

